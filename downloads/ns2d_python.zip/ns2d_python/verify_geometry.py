"""Geometry derivatives against independent browser AD and uncoloured directions."""
import json
from pathlib import Path
import numpy as np
from ns2d import Model


def main():
    rows=[]
    for data in json.loads(Path(__file__).with_name('reference_geometry.json').read_text()):
        m=Model(**data['options']);u=np.array(data['U']);d=np.array(data['d']);w=np.cos(.51*np.arange(m.nd))
        rx,jx=m.geometry_jvp(u,d);RX,JX=m.geometry_jacobian(u)
        v=.03*np.sin(.37*np.arange(m.nd));z=u.astype(complex)+1e-30j*v
        errors=dict(jvp=float(np.max(abs(rx-data['Rx']))),objective=float(abs(jx-data['Jx'])),gradient=float(np.max(abs(JX+RX.T@w-data['gradient']))),colour=float(np.max(abs(RX@d.ravel()-rx))),mixed=float(np.max(abs(m.evaluate(z)[0].imag/1e-30+rx-data['mixed']))))
        assert max(errors.values())<3e-10,(data['options'],errors)
        assert abs(JX@d.ravel()-jx)<1e-11
        if m.mode=='flow' and m.thermal=='adiabatic' and m.objective=='heatflux':assert jx==0 and np.all(JX==0)
        rows.append(dict(**data['options'],errors=errors))
    refined=[]
    for node in [False,True]:
        for mode,thermal in [('mms','isothermal'),('flow','adiabatic')]:
            m=Model(level=1,node=node,mode=mode,thermal=thermal,variable=True,objective='forcex' if mode=='flow' else 'tracking')
            u=m.initial()+1e-5*np.sin(np.arange(m.nd));d=.01*np.sin(np.arange(m.X.size)+.2).reshape(m.X.shape)
            RX,JX=m.geometry_jacobian(u);rx,jx=m.geometry_jvp(u,d)
            error=float(np.max(abs(RX@d.ravel()-rx)));assert error<1e-10,error
            assert abs(JX@d.ravel()-jx)<1e-11
            rr,cc,colors=m.geometry_pattern()
            for i in np.unique(rr):
                c=2*colors[cc[rr==i]//2]+cc[rr==i]%2
                assert len(c)==len(set(c)), 'Geometry colour collision'
            # Independent real perturbations rebuild all geometric quantities.
            h=1e-5;plus=m.with_coordinates(m.X+h*d);minus=m.with_coordinates(m.X-h*d)
            rp,jp=plus.evaluate(u);rm,jm=minus.evaluate(u)
            fd=float(np.max(abs((rp-rm)/(2*h)-rx)));assert fd<2e-8,fd
            assert abs((jp-jm)/(2*h)-jx)<1e-8
            refined.append(dict(node=node,mode=mode,dofs=m.nd,colour_error=error,fd_error=fd,coordinate_columns=RX.shape[1],nnz=RX.nnz))
    m=Model();z=m.X.copy();z[m.cells[0][0]]=z[m.cells[0][1]]
    try:m.with_coordinates(z)
    except ValueError:pass
    else:raise AssertionError('Degenerate mesh accepted')
    try:m.geometry_jvp(m.initial(),np.zeros((2,2)))
    except ValueError:pass
    else:raise AssertionError('Wrong direction shape accepted')
    state=m.initial();direction=np.ones_like(m.X)
    invalid=[lambda:m.geometry_jvp(state.astype(complex),direction),
             lambda:m.geometry_jvp(state,direction.astype(complex)),
             lambda:m.geometry_jvp(state,direction,p=m.params.astype(complex)),
             lambda:m.with_coordinates(m.X.astype(complex)).geometry_jvp(state,direction),
             lambda:m.geometry_jvp(state,np.full_like(m.X,np.nan))]
    for call in invalid:
        try:call()
        except ValueError:pass
        else:raise AssertionError('Invalid complex or non-finite geometry base accepted')
    report=dict(passed=True,cases=len(rows),max_error=max(max(r['errors'].values()) for r in rows),results=rows,refined=refined)
    print(json.dumps(report,indent=2));return report


if __name__=='__main__':main()

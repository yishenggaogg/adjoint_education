#!/usr/bin/env python3
"""Run fixed-domain MMS or laminar wall-flow primal, tangent and adjoint refinement in pure Python."""
import argparse
import json
import hashlib
import time
from pathlib import Path
import numpy as np
from scipy import sparse
from ns2d import Model
from linear import Hierarchy,fgmres
from geometry_solver import direction_from_args,analyze


def solve(m,options,p=None,start=None,tol=2e-11):
    p=m.params if p is None else p; u=m.initial(p) if start is None else start.copy(); history=[]; linear=[]
    for it in range(35):
        R,J=m.evaluate(u,p); rn=float(np.linalg.norm(R)); history.append(rn)
        print(f'Newton {it}: |R|={rn:.5e}',flush=True)
        if rn<tol:
            if not m.diagnostics(u,p)['supported']: raise RuntimeError('Unsupported reconstructed boundary branch')
            return u,J,history,linear
        # Parameter-changing FD needs the actual perturbed Jacobian. The
        # assembly routine accepts the same fixed-source parameter vector.
        A=m.jacobian(u,p=p); P=A if m.order==1 else m.jacobian(u,order=1,p=p)
        weights=np.repeat(m.vol,4); weights[m.constraints.ravel()]=0
        pre=Hierarchy(P,weights=weights,**options['pc'])
        du,report=fgmres(A,-R,pre,restart=options['restart'],max_cycles=options['cycles'],rtol=min(1e-8,max(1e-11,rn*1e-3)),atol=min(1e-13,tol*.01))
        linear.append(report); step=1.
        while step>1e-7:
            v=u+step*du
            if m.valid(v) and m.diagnostics(v,p)['supported'] and np.linalg.norm(m.evaluate(v,p)[0])<(1-1e-4*step)*rn:
                u=v; break
            step*=.5
        else: raise RuntimeError('Newton backtracking failed')
    raise RuntimeError('Newton budget exhausted')


def run(args):
    if args.fd<0 or not np.isfinite(args.fd): raise ValueError('FD step must be finite and nonnegative')
    steps=args.fd_steps if args.fd_steps is not None else ([args.fd] if args.fd else [])
    if any(not np.isfinite(h) or h<=0 for h in steps): raise ValueError('FD steps must be finite and positive')
    directions=args.fd_parameters if args.fd_parameters is not None else [args.parameter]
    started=time.perf_counter(); m=Model(args.level,args.scheme=='node',args.order,args.transport=='sutherland',mu=args.mu,Pr=args.prandtl,mode=args.case,thermal=args.thermal,objective=args.objective,M=args.mach,angle=np.deg2rad(args.angle),wall_temperature=args.wall_temperature)
    geometry_direction=direction_from_args(m,args)
    opts=dict(restart=args.restart,cycles=args.cycles,pc=dict(parts=args.parts,overlap=args.overlap,fill=args.fill,ordering=args.ordering,global_its=args.global_its,local_its=args.local_its,omega=args.omega,shift=args.shift))
    print(f'{m.nc} control volumes, {m.nd} unknowns; Arnoldi V/Z estimate {(2*min(m.nd,args.restart)+1)*m.nd*8/2**20:.1f} MiB',flush=True)
    u,J,history,primal_linear=solve(m,opts,tol=1e-12 if steps or args.geometry_fd_steps else 2e-11); A=m.jacobian(u); P=A if args.order==1 else m.jacobian(u,order=1)
    j=m.objective_gradient(u); Rp,Jp=m.parameter_derivatives(u); weights=np.repeat(m.vol,4); weights[m.constraints.ravel()]=0
    # Factor P^T itself: restricted ASM(P^T) is NOT the transpose of ASM(P).
    adjpc=Hierarchy(P.T.tocsr(),weights=weights,**opts['pc'])
    psi,adj=fgmres(A.T,-j,adjpc,restart=args.restart,max_cycles=args.cycles,rtol=1e-11)
    tanpc=Hierarchy(P,weights=weights,**opts['pc']); k=args.parameter
    tangent,tan=fgmres(A,-Rp[:,k],tanpc,restart=args.restart,max_cycles=args.cycles,rtol=1e-11)
    gradient=Jp+psi@Rp; tangent_gradient=float(Jp[k]+j@tangent)
    primal_error=None
    if m.mode=='mms':
        exact=m.initial(); den=np.sum(np.repeat(m.vol,4)*exact**2)
        primal_error=float(np.sqrt(np.sum(np.repeat(m.vol,4)*(u-exact)**2)/den))
    physical=m.evaluate(u,details=True)
    output=dict(schema=3,scope='MMS or laminar wall-flow; physical and frozen-topology coordinate derivatives; no independent continuum solver',case=m.mode,thermal=m.thermal,objective=m.objective,parameters=m.params.tolist(),force=physical['force'].tolist(),heat=float(physical['heat']),method='coloured complex-step sparse Jacobian; right FGMRES / Richardson / restricted ASM / ILU(k)',level=args.level,node=m.node,order=args.order,variable=m.variable,cells=m.nc,dofs=m.nd,h=float(np.sqrt(m.vol.max())),J=float(J),gradient=gradient.tolist(),parameter=k,tangent_gradient=tangent_gradient,duality_error=float(abs(tangent_gradient-gradient[k])),primal_residual=history[-1],primal_error=primal_error,reconstruction_error=m.reproduction_error,diagnostics=m.diagnostics(u),primal_history=history,primal_linear=primal_linear,adjoint=adj,tangent=tan,options=opts)
    if steps:
        checks=[]
        for parameter in directions:
            for step in steps:
                p=m.params.copy(); p[parameter]+=step; _,jp,hp,_=solve(m,opts,p,u,tol=1e-12)
                p=m.params.copy(); p[parameter]-=step; _,jm,hm,_=solve(m,opts,p,u,tol=1e-12)
                fd=float((jp-jm)/(2*step)); error=float(abs(fd-gradient[parameter]))
                checks.append(dict(parameter=parameter,step=step,gradient=fd,adjoint=float(gradient[parameter]),absolute_difference=error,relative_difference=error/max(abs(gradient[parameter]),1e-14),forward=float((jp-J)/step),backward=float((J-jm)/step),taylor_remainder=float(abs(jp-J-step*gradient[parameter])),plus_residual=hp[-1],minus_residual=hm[-1]))
        output['fd_checks']=checks
        if len(checks)==1: output['fd']=checks[0]
    geometry_fields={};RX=None
    if geometry_direction is not None or args.geometry_all:
        output['geometry'],geometry_fields,RX=analyze(m,u,psi,j,A,tanpc,opts,solve,direction=geometry_direction,full=args.geometry_all,steps=args.geometry_fd_steps or [])
        if args.geometry_shape: spec=dict(kind='coarse_shape',name=args.geometry_shape)
        elif args.geometry_node is not None: spec=dict(kind='vertex',node=args.geometry_node,axis=args.geometry_axis)
        elif args.geometry_direction: spec=dict(kind='file',sha256=hashlib.sha256(Path(args.geometry_direction).read_bytes()).hexdigest())
        else: spec=dict(kind='full_gradient')
        output['geometry']['direction_spec']=spec
    directory=Path(args.output); directory.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(directory/'fields.npz',coordinates=m.cent,mesh_coordinates=m.X,volumes=m.vol,state=u,adjoint=psi,tangent=tangent,**geometry_fields)
    if args.save_matrices:
        sparse.save_npz(directory/'jacobian.npz',A); sparse.save_npz(directory/'preconditioner.npz',P)
        if RX is not None:sparse.save_npz(directory/'geometry_jacobian.npz',RX)
    output['seconds']=time.perf_counter()-started
    (directory/'result.json').write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
    summary={k:output[k] for k in ['cells','dofs','J','gradient','duality_error','primal_residual','seconds']}
    if 'directional' in output.get('geometry',{}):
        summary['geometry_directional_gradient']=output['geometry']['directional']['adjoint']
        summary['geometry_duality_error']=output['geometry']['directional']['duality_error']
    print(json.dumps(summary,indent=2))
    return output


def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--level',type=int,default=0); p.add_argument('--scheme',choices=['cell','node'],default='node')
    p.add_argument('--order',type=int,choices=[1,2],default=2); p.add_argument('--transport',choices=['constant','sutherland'],default='sutherland')
    p.add_argument('--case',choices=['mms','flow'],default='mms'); p.add_argument('--thermal',choices=['isothermal','adiabatic'],default='isothermal')
    p.add_argument('--objective',choices=['tracking','forcex','forcey','heatflux'],default='tracking')
    p.add_argument('--mu',type=float,default=.2); p.add_argument('--prandtl',type=float,default=.72)
    p.add_argument('--mach',type=float,default=.12); p.add_argument('--angle',type=float,default=np.rad2deg(.15),help='Incidence in degrees')
    p.add_argument('--wall-temperature',type=float,default=None,help='Default: 1.05 for wall flow; 1 for MMS')
    p.add_argument('--parts',type=int,default=4); p.add_argument('--overlap',type=int,default=1); p.add_argument('--fill',type=int,default=1)
    p.add_argument('--ordering',choices=['natural','rcm'],default='natural'); p.add_argument('--global-its',type=int,default=1); p.add_argument('--local-its',type=int,default=1)
    p.add_argument('--omega',type=float,default=1.); p.add_argument('--shift',type=float,default=0.)
    p.add_argument('--restart',type=int,default=100); p.add_argument('--cycles',type=int,default=20)
    p.add_argument('--parameter',type=int,choices=range(6),default=5); p.add_argument('--fd',type=float,default=0.)
    p.add_argument('--fd-steps',type=float,nargs='+',help='Override --fd with a step sweep')
    p.add_argument('--fd-parameters',type=int,nargs='+',choices=range(6),help='Physical parameter indices to check')
    geometry=p.add_mutually_exclusive_group()
    geometry.add_argument('--geometry-node',type=int,help='Selected mesh vertex; a unit coordinate perturbation')
    geometry.add_argument('--geometry-direction',help='JSON file containing one [dx,dy] pair per mesh vertex')
    geometry.add_argument('--geometry-shape',choices=['inner-scale'],help='Refinement-consistent inner-boundary scaling with a fixed far boundary')
    p.add_argument('--geometry-axis',choices=['x','y'],default='x')
    p.add_argument('--geometry-all',action='store_true',help='Assemble sparse R_X and return every coordinate gradient')
    p.add_argument('--geometry-fd-steps',type=float,nargs='+',help='Reconverge on both deformed meshes for each step')
    p.add_argument('--save-matrices',action='store_true'); p.add_argument('--output',default='results/ns2d')
    return p


if __name__=='__main__':
    args=parser().parse_args()
    if args.fd<0 or not np.isfinite(args.fd): raise SystemExit('FD step must be finite and nonnegative')
    run(args)

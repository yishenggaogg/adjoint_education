"""Converged shape sensitivities: tangent, adjoint, LU and deformed-mesh FD."""
import contextlib,json
from pathlib import Path
import numpy as np
from scipy.sparse.linalg import spsolve
from ns2d import Model
from run import solve
from linear import Hierarchy,fgmres


def main():
    options=dict(restart=100,cycles=20,pc=dict(parts=4,overlap=1,fill=1,ordering='natural',global_its=1,local_its=1,omega=1.,shift=0.))
    rows=[]
    configs=[(0,n,o,mode,thermal) for n in [False,True] for o in [1,2] for mode,thermal in [('mms','isothermal'),('flow','isothermal'),('flow','adiabatic')]]
    configs += [(1,False,2,'mms','isothermal'),(1,True,2,'flow','adiabatic')]
    with open('geometry_solver_iterations.log','w') as log:
        for level,node,order,mode,thermal in configs:
            m=Model(level=level,node=node,order=order,mode=mode,thermal=thermal,variable=True)
            with contextlib.redirect_stdout(log):u,_,hist,_=solve(m,options,tol=1e-12)
            A=m.jacobian(u);P=A if order==1 else m.jacobian(u,order=1)
            weights=np.repeat(m.vol,4);weights[m.constraints.ravel()]=0
            forward_pc=Hierarchy(P,weights=weights,**options['pc']);adjoint_pc=Hierarchy(P.T.tocsr(),weights=weights,**options['pc'])
            direction=.02*np.sin(np.arange(m.X.size)+.3).reshape(m.X.shape)
            rx,_=m.geometry_jvp(u,direction);tangent,tan=fgmres(A,-rx,forward_pc,rtol=1e-11)
            direct=spsolve(A.tocsc(),-rx);lu=float(np.max(abs(tangent-direct)));assert lu<1e-8,lu
            steps=[1e-3,1e-4];perturbed=[]
            for h in steps:
                plus=m.with_coordinates(m.X+h*direction);minus=m.with_coordinates(m.X-h*direction)
                with contextlib.redirect_stdout(log):up,_,hp,_=solve(plus,options,start=u,tol=1e-12);um,_,hm,_=solve(minus,options,start=u,tol=1e-12)
                perturbed.append((h,plus,minus,up,um,hp[-1],hm[-1]))
            objectives=['tracking','heatflux'] if mode=='mms' else ['forcex','forcey','heatflux']
            for objective in objectives:
                m.objective=objective;j=m.objective_gradient(u);psi,adj=fgmres(A.T,-j,adjoint_pc,rtol=1e-11)
                RX,JX=m.geometry_jacobian(u);rx,jx=m.geometry_jvp(u,direction)
                gradient=JX+RX.T@psi;ga=float(jx+psi@rx);gt=float(jx+j@tangent)
                error=abs(ga-gt);assert error<1e-8,error
                assert abs(gradient@direction.ravel()-ga)<1e-10
                fd=[]
                for h,plus,minus,up,um,rp,rm in perturbed:
                    plus.objective=minus.objective=objective
                    g=float((plus.evaluate(up)[1]-minus.evaluate(um)[1])/(2*h));e=abs(g-ga)
                    assert e<max(3e-8,abs(ga)*3e-5),(level,node,order,mode,thermal,objective,h,e,ga)
                    fd.append(dict(step=h,gradient=g,absolute_error=e,plus_residual=rp,minus_residual=rm))
                if mode=='flow' and thermal=='adiabatic' and objective=='heatflux':assert ga==0 and np.all(gradient==0)
                row=dict(level=level,node=node,order=order,mode=mode,thermal=thermal,objective=objective,dofs=m.nd,vertices=len(m.X),primal_residual=hist[-1],tangent_residual=tan['residual'],adjoint_residual=adj['residual'],gradient=ga,duality_error=error,tangent_lu_error=lu,fd=fd)
                rows.append(row);print(json.dumps(row),flush=True)
    report=dict(passed=True,configurations=len(configs),objective_cases=len(rows),results=rows)
    Path('geometry_solver_validation.json').write_text(json.dumps(report,indent=2)+'\n');return report


if __name__=='__main__':main()

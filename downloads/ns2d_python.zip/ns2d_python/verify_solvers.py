import sys,json,contextlib
# All numerical imports are local Python modules.
import numpy as np
from scipy.sparse.linalg import spsolve
from ns2d import Model
from run import solve
from linear import Hierarchy,fgmres
opts=dict(restart=100,cycles=20,pc=dict(parts=4,overlap=1,fill=1,ordering='natural',global_its=1,local_its=1,omega=1.,shift=0.))
results=[]
with open('audit_python_solver_iterations.log','w') as log:
 for level,node,order,variable in [(0,n,o,v) for n in (False,True) for o in (1,2) for v in (False,True)]+[(2,False,2,True),(2,True,2,True)]:
  m=Model(level=level,node=node,order=order,variable=variable)
  with contextlib.redirect_stdout(log):u,J,hist,_=solve(m,opts,tol=1e-12)
  A=m.jacobian(u); P=m.jacobian(u,order=1); j=m.objective_gradient(u); rp,jp=m.parameter_derivatives(u)
  psi,report=fgmres(A.T,-j,Hierarchy(P.T.tocsr(),**opts['pc']),rtol=1e-11)
  direct=spsolve(A.T.tocsc(),-j); lu=float(np.max(abs(psi-direct))); assert lu<1e-8,lu
  grad=jp+psi@rp; dual=[]; fd=[]
  for k in range(6):
   tan,r=fgmres(A,-rp[:,k],Hierarchy(P,**opts['pc']),rtol=1e-11)
   e=float(abs(j@tan+jp[k]-grad[k]));assert e<1e-9,e;dual.append(e)
   if level==0 or k==5:
    step=1e-4; pa=m.params.copy();pb=pa.copy();pa[k]+=step;pb[k]-=step
    with contextlib.redirect_stdout(log):_,ja,ha,_=solve(m,opts,pa,u,tol=1e-12);_,jb,hb,_=solve(m,opts,pb,u,tol=1e-12)
    g=(ja-jb)/(2*step);e=float(abs(g-grad[k]));assert e<max(2e-9,abs(grad[k])*3e-6),(level,node,order,variable,k,e,grad[k]);fd.append(dict(parameter=k,fd=float(g),absolute_error=e,relative_error=e/max(abs(grad[k]),1e-14),plus_residual=ha[-1],minus_residual=hb[-1]))
  row=dict(level=level,node=node,order=order,variable=variable,dofs=m.nd,primal_residual=hist[-1],adjoint_residual=report['residual'],lu_error=lu,duality_max=max(dual),fd=fd,gradient=grad.tolist())
  results.append(row); print(json.dumps(row),flush=True)
  with open('audit_python_solvers.json','w') as f: json.dump(dict(passed=True,completed_cases=len(results),results=results),f,indent=2)

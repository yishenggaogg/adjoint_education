"""Plot offline gradients, true residuals and (only for MMS) exact-state errors."""
import argparse,json,math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter,FuncFormatter,MaxNLocator


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('result'); p.add_argument('--output',default='refinement.png')
    p.add_argument('--parameter',type=int,choices=range(6),default=5);p.add_argument('--geometry',action='store_true',help='Plot the selected geometric direction instead of a physical parameter'); a=p.parse_args()
    data=json.loads(Path(a.result).read_text()); rows=data if isinstance(data,list) else [data]
    if not rows: p.error('No completed results')
    if a.geometry and any('directional' not in r.get('geometry',{}) for r in rows):p.error('Every result needs a geometric direction')
    fig,axes=plt.subplots(1,3,figsize=(14,4),layout='constrained')
    def key(r):
        return (r.get('case','mms'),r['node'],r['order'],r['variable'],r.get('thermal','isothermal'),r.get('objective','tracking'),tuple(r.get('parameters',[])),json.dumps(r.get('geometry',{}).get('direction_spec',{}),sort_keys=True) if a.geometry else '')
    errors=False
    for group in sorted({key(r) for r in rows}):
        part=sorted((r for r in rows if key(r)==group),key=lambda r:r['level']); mode,node,order,variable,thermal,obj,parameters,geometry=group
        name=f'{mode}, {"node" if node else "cell"}, O{order}, {"Sutherland" if variable else "constant"}, {thermal}, {obj}'
        if a.geometry:
            spec=json.loads(geometry)
            label=spec.get('name',('vertex '+str(spec['node'])+' '+spec['axis']) if spec.get('kind')=='vertex' else spec.get('kind','direction'))
            name+=' '+label
        if len({key(r)[-2] for r in rows})>1: name+=f', p={parameters}'
        axes[0].semilogx([1/r['h'] for r in part],[(r['geometry']['directional']['adjoint'] if a.geometry else r['gradient'][a.parameter]) for r in part],'o-',label=name)
        exact=[r for r in part if r['primal_error'] is not None]
        if exact:
            errors=True;axes[1].loglog([1/r['h'] for r in exact],[r['primal_error'] for r in exact],'o-',label=name)
        axes[2].semilogy([r['level'] for r in part],[max(r['primal_residual'],1e-30) for r in part],'o-',label=name+' primal')
        axes[2].semilogy([r['level'] for r in part],[max(r['adjoint']['residual'],1e-30) for r in part],'x--',label=name+' adjoint')
    axes[0].set(xlabel='1/h',ylabel='Geometric directional derivative' if a.geometry else f'Objective gradient, parameter {a.parameter}')
    axes[1].set(xlabel='1/h',ylabel='Relative exact-state error (MMS only)')
    if not errors:
        axes[1].set_axis_off();axes[1].text(.5,.5,'No exact wall-flow solution provided',ha='center',va='center',transform=axes[1].transAxes)
    ticks=sorted({1/r['h'] for r in rows});step=max(1,math.ceil(len(ticks)/6));ticks=ticks[::step]+([] if ticks[-1] in ticks[::step] else [ticks[-1]])
    for ax in axes[:2]:
        ax.set_xticks(ticks);ax.xaxis.set_major_formatter(FuncFormatter(lambda x,_:f'{x:.3g}'));ax.xaxis.set_minor_formatter(NullFormatter())
    axes[2].xaxis.set_major_locator(MaxNLocator(integer=True))
    axes[2].set(xlabel='Refinement level',ylabel='True residual norm')
    for ax in axes:
        ax.grid(alpha=.2)
        if ax.lines: ax.legend(fontsize=6)
    fig.savefig(a.output,dpi=180)


if __name__=='__main__':main()

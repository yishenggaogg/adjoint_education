"""Independent checks against browser AD exports, including wall heat/force targets."""
import json
from pathlib import Path
import numpy as np
from ns2d import Model


def main():
    results=[]
    for d in json.loads(Path(__file__).with_name('reference_flow.json').read_text()):
        m=Model(**d['options']); u=np.array(d['U']); v=np.sin(.37*np.arange(m.nd)); w=np.cos(.51*np.arange(m.nd))
        e=m.evaluate(u,details=True); A=m.jacobian(u); j=m.objective_gradient(u); rp,jp=m.parameter_derivatives(u)
        errors=dict(residual=float(np.max(abs(e['R']-d['R']))),objective=float(abs(e['J']-d['J'])),jvp=float(np.max(abs(A@v-d['jvp']['R']))),vjp=float(np.max(abs(A.T@w+j-d['vjp']['U']))),objective_gradient=float(np.max(abs(j-d['j']))),parameter=float(np.max(abs(rp-np.array(d['Rp']).T))),objective_parameter=float(np.max(abs(jp-d['jp']))),force=float(np.max(abs(e['force']-d['force']))),heat=float(abs(e['heat']-d['heat'])))
        assert max(errors.values())<2e-10,(d['options'],errors)
        # Global objective differentiation must not alias colour groups.
        z=u.astype(complex)+1e-30j*v
        assert abs(j@v-m.evaluate(z)[1].imag/1e-30)<1e-10
        # Local conservation before strong boundary equations replace rows.
        raw=e['raw'].reshape(-1,4).sum(axis=0)
        net=np.sum(m.fw[~m.interior,None]*e['flux'][~m.interior],axis=0)-m.src.sum(axis=0)
        net[3]-=m.params[5]*m.heating.sum()
        assert np.max(abs(net-raw))<1e-12
        if m.mode=='flow':
            assert np.all(e['flux'][m.wall,0]==0)
            if m.thermal=='adiabatic':
                assert e['heat']==0 and np.all(e['flux'][m.wall,3]==0)
                assert np.max(abs(rp[:,4]))==0 and jp[4]==0
                if m.objective=='heatflux': assert np.all(j==0) and e['J']==0
        results.append(dict(**d['options'],errors=errors))
    report=dict(passed=True,cases=len(results),max_error=max(max(r['errors'].values()) for r in results),results=results)
    print(json.dumps(report,indent=2));return report


if __name__=='__main__':main()

"""Frozen-topology shape sensitivities using the actual discrete residual."""
import json
from pathlib import Path
import numpy as np
from linear import fgmres
from ns2d import mesh


def direction_from_args(m,args):
    direction=None
    if args.geometry_node is not None:
        if not 0<=args.geometry_node<len(m.X):raise ValueError('Geometry node is outside this mesh')
        direction=np.zeros_like(m.X);direction[args.geometry_node,0 if args.geometry_axis=='x' else 1]=1
    elif args.geometry_direction:
        direction=np.asarray(json.loads(Path(args.geometry_direction).read_text()),dtype=float)
        if direction.shape!=m.X.shape or not np.all(np.isfinite(direction)):
            raise ValueError('Direction JSON must be a finite (number of mesh vertices,2) array')
    elif args.geometry_shape:
        coarse,_=mesh(0);r=np.linalg.norm(coarse,axis=1);t=np.clip((r-r.min())/(r.max()-r.min()),0,1)
        weight=(1-t)**2*(1+2*t)
        # Refinement is linear in coordinates. Propagate the coarse direction
        # by that SAME map, preserving one physical deformation across levels.
        direction,_=mesh(m.level,base_coordinates=coarse*weight[:,None])
    steps=args.geometry_fd_steps or []
    if steps and direction is None:raise ValueError('Geometry FD requires --geometry-node, --geometry-direction or --geometry-shape')
    if any(not np.isfinite(h) or h<=0 for h in steps):raise ValueError('Geometry FD steps must be finite and positive')
    return direction


def analyze(m,u,psi,j,A,pre,options,solve,direction=None,full=False,steps=()):
    report=dict(semantics='fixed topology, fixed boundary partition, Eulerian analytic data; coordinate order x0,y0,x1,y1,...',vertices=len(m.X))
    fields={};RX=None
    if full:
        def progress(k,n):
            if k==1 or k==n or k%max(1,n//10)==0:print(f'Geometry Jacobian groups {k}/{n}',flush=True)
        RX,JX=m.geometry_jacobian(u,progress)
        gradient=JX+RX.T@psi
        fields['geometry_gradient']=gradient.reshape(m.X.shape)
        report.update(gradient=fields['geometry_gradient'].tolist(),explicit_objective_gradient=JX.reshape(m.X.shape).tolist(),jacobian_nnz=RX.nnz,coordinate_colours=int(m.geometry_pattern()[2].max()+1))
    if direction is not None:
        rx,jx=m.geometry_jvp(u,direction)
        tangent,linear=fgmres(A,-rx,pre,restart=options['restart'],max_cycles=options['cycles'],rtol=1e-11)
        adjoint=float(jx+psi@rx);forward=float(jx+j@tangent)
        report['directional']=dict(adjoint=adjoint,tangent=forward,duality_error=abs(adjoint-forward),explicit_objective=jx,linear=linear)
        fields.update(geometry_direction=direction,geometry_tangent=tangent)
        if full:report['directional']['assembled_difference']=float(abs(gradient@direction.ravel()-adjoint))
        if steps:
            checks=[];J=float(m.evaluate(u)[1])
            for h in steps:
                plus=m.with_coordinates(m.X+h*direction);minus=m.with_coordinates(m.X-h*direction)
                _,jp,hp,_=solve(plus,options,start=u,tol=1e-12)
                _,jm,hm,_=solve(minus,options,start=u,tol=1e-12)
                central=float((jp-jm)/(2*h));error=abs(central-adjoint)
                checks.append(dict(step=h,central=central,adjoint=adjoint,absolute_difference=error,relative_difference=error/max(abs(adjoint),1e-14),forward=float((jp-J)/h),backward=float((J-jm)/h),taylor_remainder=float(abs(jp-J-h*adjoint)),plus_residual=hp[-1],minus_residual=hm[-1]))
            report['fd_checks']=checks
    return report,fields,RX

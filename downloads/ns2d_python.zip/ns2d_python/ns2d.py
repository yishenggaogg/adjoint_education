"""Pure Python FV kernel: fixed-polygon MMS and laminar wall flow.

State Jacobians are sparse, explicitly assembled by coloured complex-step
arithmetic (h=1e-30). Adjoint products use the transpose of THAT Jacobian.
This offline refinement path is not the browser's matrix-free AD tape.
"""
import json
from pathlib import Path
import numpy as np
from scipy import sparse


def mesh(level,base_coordinates=None):
    data = json.loads(Path(__file__).with_name('coarse_mesh.json').read_text())
    X, C = data['X'], data['C']
    if base_coordinates is not None:
        a=np.asarray(base_coordinates)
        if a.shape!=np.shape(X) or not np.all(np.isfinite(a)): raise ValueError('Invalid coarse coordinate array')
        X=a.tolist()
    for _ in range(level):
        edges, cells = {}, []
        def mid(a, b):
            key = tuple(sorted((a, b)))
            if key not in edges:
                edges[key] = len(X)
                X.append(((np.array(X[a])+X[b])/2).tolist())
            return edges[key]
        for c in C:
            mids = [mid(a, c[(k+1)%len(c)]) for k, a in enumerate(c)]
            if len(c) == 3:
                a,b,d=c; ab,bd,da=mids
                cells.extend([[a,ab,da],[ab,b,bd],[da,bd,d],[ab,bd,da]])
            else:
                j=len(X); X.append(np.mean(np.array([X[i] for i in c]),axis=0).tolist())
                cells.extend([[a,mids[k],j,mids[(k+3)%4]] for k,a in enumerate(c)])
        C=cells
    return np.asarray(X), C


def cons(r,u,v,T):
    return np.stack((r,r*u,r*v,r*(2.5*T+.5*(u*u+v*v))),axis=-1)


def prim(U):
    r=U[...,0]; u=U[...,1]/r; v=U[...,2]/r
    T=(U[...,3]/r-.5*(u*u+v*v))/2.5
    return r,u,v,T


def exact(x, gradients=False):
    waves=((1,.025,.7,.4,False),(.22,.025,.5,.6,False),
           (.055,.01,.8,-.3,True),(1,.04,.6,.7,False))
    q=[]; g=[]
    for base,amp,a,b,cosine in waves:
        t=a*x[...,0]+b*x[...,1]
        q.append(base+amp*(np.cos(t) if cosine else np.sin(t)))
        d=amp*(-np.sin(t) if cosine else np.cos(t))
        g.append(np.stack((a*d,b*d),axis=-1))
    return (q,g) if gradients else cons(*q)


def flux(U,n):
    r,u,v,T=prim(U); un=u*n[...,0]+v*n[...,1]; p=r*T
    return np.stack((r*un,U[...,1]*un+p*n[...,0],
                     U[...,2]*un+p*n[...,1],(U[...,3]+p)*un),axis=-1)


def primitive_gradient(U,G):
    r,u,v,T=prim(U)
    gu=(G[...,1]-u[...,None]*G[...,0])/r[...,None]
    gv=(G[...,2]-v[...,None]*G[...,0])/r[...,None]
    gt=((G[...,3]-(U[...,3]/r)[...,None]*G[...,0])/r[...,None]
        -u[...,None]*gu-v[...,None]*gv)/2.5
    return np.stack((gu,gv,gt),axis=-2)


def viscous(q,G,n,p,variable):
    r,u,v,T=q
    mu=p[2]*1.4*T**1.5/(T+.4) if variable else p[2]+np.zeros_like(T)
    kappa=3.5*mu/p[3]; gu,gv,gt=G[...,0,:],G[...,1,:],G[...,2,:]
    div=gu[...,0]+gv[...,1]
    txx=mu*(2*gu[...,0]-2/3*div); tyy=mu*(2*gv[...,1]-2/3*div)
    txy=mu*(gu[...,1]+gv[...,0])
    tx=txx*n[...,0]+txy*n[...,1]; ty=txy*n[...,0]+tyy*n[...,1]
    heat=-kappa*np.sum(gt*n,axis=-1)
    return np.stack((np.zeros_like(tx),tx,ty,u*tx+v*ty-heat),axis=-1),heat


def source(x,p,variable):
    """Analytic divergence, including Sutherland derivatives.

    Unlike imag(F(x+ih))/h this is holomorphic in x, so an OUTER
    complex coordinate perturbation survives the spatial differentiation.
    """
    q,g=exact(x,True); r,u,v,T=q; gr,gu,gv,gt=g
    waves=((.025,.7,.4,False),(.025,.5,.6,False),(.01,.8,-.3,True),(.04,.6,.7,False))
    h=[]
    for amp,a,b,cosine in waves:
        t=a*x[...,0]+b*x[...,1]; d=-amp*(np.cos(t) if cosine else np.sin(t))
        h.append(d[...,None]*np.array([a*a,a*b,b*b]))
    _,hu,hv,ht=h
    mu=p[2]*1.4*T**1.5/(T+.4) if variable else p[2]+np.zeros_like(T)
    mut=mu*(1.5/T-1/(T+.4)) if variable else np.zeros_like(T)
    mux,muy=mut*gt[...,0],mut*gt[...,1]
    sx=4/3*gu[...,0]-2/3*gv[...,1]; sy=4/3*gv[...,1]-2/3*gu[...,0]; shear=gu[...,1]+gv[...,0]
    tx,ty,xy=mu*sx,mu*sy,mu*shear
    divx=mux*sx+mu*(4/3*hu[...,0]-2/3*hv[...,1])+muy*shear+mu*(hu[...,2]+hv[...,1])
    divy=mux*shear+mu*(hu[...,1]+hv[...,0])+muy*sy+mu*(4/3*hv[...,2]-2/3*hu[...,1])
    gp=gr*T[...,None]+r[...,None]*gt
    mass=gr[...,0]*u+r*gu[...,0]+gr[...,1]*v+r*gv[...,1]
    mx=gr[...,0]*u*u+2*r*u*gu[...,0]+gp[...,0]+gr[...,1]*u*v+r*(gu[...,1]*v+u*gv[...,1])-divx
    my=gr[...,0]*u*v+r*(gu[...,0]*v+u*gv[...,0])+gr[...,1]*v*v+2*r*v*gv[...,1]+gp[...,1]-divy
    enthalpy=3.5*T+.5*(u*u+v*v); H=r*enthalpy
    gH=gr*enthalpy[...,None]+r[...,None]*(3.5*gt+u[...,None]*gu+v[...,None]*gv)
    conduction=3.5/p[3]*(mut*np.sum(gt*gt,axis=-1)+mu*(ht[...,0]+ht[...,2]))
    energy=gH[...,0]*u+gH[...,1]*v+H*(gu[...,0]+gv[...,1])-(gu[...,0]*tx+(gu[...,1]+gv[...,0])*xy+gv[...,1]*ty+u*divx+v*divy+conduction)
    return np.stack((mass,mx,my,energy),axis=-1)


def scatter_sum(ids,values,size):
    """np.bincount equivalent retaining complex coordinate derivatives."""
    out=np.zeros((size,)+values.shape[1:],dtype=values.dtype)
    np.add.at(out,ids,values)
    return out


def analytic_norm(x,axis=-1):
    # No conjugation: extension of the real Euclidean norm on its positive branch.
    return np.sqrt(np.sum(x*x,axis=axis))


class Model:
    def __init__(self,level=0,node=False,order=2,variable=False,mu=.2,Pr=.72,mode="mms",thermal="isothermal",objective="tracking",M=.12,angle=.15,wall_temperature=None,coordinates=None,_reference=None):
        if not isinstance(level,int) or level<0 or level>8 or order not in (1,2):
            raise ValueError('level must be 0..8; order must be 1 or 2')
        if mode not in ('mms','flow') or thermal not in ('isothermal','adiabatic') or objective not in ('tracking','forcex','forcey','heatflux'):
            raise ValueError('Invalid case, wall condition or objective')
        self.node,self.order,self.variable=node,order,variable
        self.mode,self.thermal,self.objective=mode,thermal,objective
        temperature=(1.05 if mode=='flow' else 1.) if wall_temperature is None else wall_temperature
        if mode=='mms' and temperature!=1.: raise ValueError('MMS inner-temperature baseline must be 1; use parameter perturbations for derivatives')
        self.params=np.array([M,angle,mu,Pr,temperature,0.])
        if not np.all(np.isfinite(self.params)) or min(mu,Pr,temperature)<=0 or M<0:
            raise ValueError('Finite positive transport and temperature, nonnegative Mach required')
        X0,C=mesh(level)
        X=X0 if coordinates is None else np.asarray(coordinates).copy()
        if X.shape!=X0.shape or not np.all(np.isfinite(X)): raise ValueError('Coordinate shape or values are invalid')
        if np.iscomplexobj(X) and _reference is None: raise ValueError('Complex geometry needs a frozen real reference')
        self.level=level
        self._options=dict(level=level,node=node,order=order,variable=variable,mu=mu,Pr=Pr,mode=mode,thermal=thermal,objective=objective,M=M,angle=angle,wall_temperature=temperature)
        self._reference=_reference
        Xtag=X if _reference is None else _reference.X
        self.X,self.cells=X,C
        self.inner_nodes=np.linalg.norm(Xtag,axis=1)<1.1 if _reference is None else _reference.inner_nodes
        self._geometry_dtype=np.result_type(X,float)
        edges=[]; keys={}
        for i,c in enumerate(C):
            for k,a in enumerate(c):
                b=c[(k+1)%len(c)]; key=tuple(sorted((a,b)))
                if key in keys: edges[keys[key]][3]=i
                else: keys[key]=len(edges); edges.append([a,b,i,-1])
        cent0=np.array([X[c].mean(axis=0) for c in C])
        mids=np.array([(X[a]+X[b])/2 for a,b,_,_ in edges])
        points=np.vstack((X,cent0,mids)); off=len(X); moff=off+len(C)
        faces=[]
        for j,(a,b,l,r) in enumerate(edges):
            bc=0 if r>=0 else (1 if max(np.linalg.norm(Xtag[a]),np.linalg.norm(Xtag[b]))<1.1 else 2)
            if not node: faces.append((l,r,bc,[(a,b,1)]))
            else:
                aa,bb=sorted((a,b)); seg=[]
                for ci in (l,r):
                    if ci<0: continue
                    c=C[ci]; sign=1 if c[(c.index(aa)+1)%len(c)]==bb else -1
                    seg.append((moff+j,off+ci,sign))
                faces.append((aa,bb,0,seg))
                if r<0: faces.extend([(a,-1,bc,[(a,moff+j,1)]),(b,-1,bc,[(moff+j,b,1)])])
        faces.sort(key=lambda f:(f[2],f[0],f[1])); self.faces=faces
        nc=len(X) if node else len(C); self.nc=nc; self.nd=4*nc
        nb=[set() for _ in range(nc)]
        for l,r,_,_ in faces:
            if r>=0: nb[l].add(r); nb[r].add(l)
        self.stencil=[]
        for i in range(nc):
            seen={i}; front=[i]
            for _ in range(5):
                if len(seen)>=min(12,nc): break
                nxt=[]
                for a in front:
                    for b in sorted(nb[a]):
                        if b not in seen: seen.add(b); nxt.append(b)
                front=nxt
            self.stencil.append(sorted(seen-{i}))
        # Seven-point triangle quadrature, including median-dual subpolygons.
        bary=np.array([[1/3,1/3,1/3,.225],
            [.05971587178977,.470142064105115,.470142064105115,.132394152788506],
            [.470142064105115,.05971587178977,.470142064105115,.132394152788506],
            [.470142064105115,.470142064105115,.05971587178977,.132394152788506],
            [.797426985353087,.101286507323456,.101286507323456,.125939180544827],
            [.101286507323456,.797426985353087,.101286507323456,.125939180544827],
            [.101286507323456,.101286507323456,.797426985353087,.125939180544827]])
        triangles=[]; owners=[]
        for ci,c in enumerate(C):
            polys=[(ci,X[c])] if not node else [(a,np.array([X[a],(X[a]+X[c[(k+1)%len(c)]])/2,cent0[ci],(X[a]+X[c[k-1]])/2])) for k,a in enumerate(c)]
            for i,poly in polys:
                for k in range(1,len(poly)-1): triangles.append([poly[0],poly[k],poly[k+1]]); owners.extend([i]*7)
        tri=np.array(triangles); d=tri[:,1]-tri[:,0]; e=tri[:,2]-tri[:,0]
        area=.5*(d[:,0]*e[:,1]-d[:,1]*e[:,0])
        if not np.all(area.real>1e-14): raise ValueError('Nonpositive quadrature triangle')
        self.qx=np.einsum('qa,tad->tqd',bary[:,:3],tri).reshape(-1,2)
        self.qw=(area[:,None]*bary[:,3]).ravel(); self.qi=np.array(owners)
        self.vol=scatter_sum(self.qi,self.qw,nc)
        self.cent=X.copy() if node else np.column_stack([scatter_sum(self.qi,self.qw*self.qx[:,d],nc)/self.vol for d in range(2)])
        delta=self.qx-self.cent[self.qi]
        self.mom=np.zeros((nc,3)) if node else np.column_stack([scatter_sum(self.qi,self.qw*v,nc)/self.vol for v in (delta[:,0]**2,delta[:,0]*delta[:,1],delta[:,1]**2)])
        row=[]; col=[]; vals=[[] for _ in range(5)]
        self.reproduction_error=0.
        for i,s in enumerate(self.stencil):
            d=self.cent[s]-self.cent[i]; dm=self.mom[s]-self.mom[i]
            B=np.column_stack((d[:,0],d[:,1],d[:,0]**2+dm[:,0],d[:,0]*d[:,1]+dm[:,1],d[:,1]**2+dm[:,2]))
            w=1/np.sum(d*d,axis=1); W=np.linalg.solve(B.T@(w[:,None]*B),B.T*w)
            self.reproduction_error=max(self.reproduction_error,float(np.max(abs(W@B-np.eye(5)))))
            row.extend([i]*(len(s)+1)); col.extend(s+[i])
            for k in range(5): vals[k].extend([*W[k],-W[k].sum()])
        if self.reproduction_error>1e-8: raise RuntimeError('Reconstruction reproduction failed')
        self.fit=[sparse.csr_matrix((v,(row,col)),shape=(nc,nc)) for v in vals]
        L=[]; R=[]; bc=[]; xn=[]; normals=[]; weights=[]
        for l,r,tag,segs in faces:
            for a,b,sign in segs:
                d=points[b]-points[a]; nv=sign*np.array([d[1],-d[0]]); length=analytic_norm(nv)
                if not np.isfinite(length) or length.real<=1e-10: raise ValueError("Degenerate face")
                for z in (-1/np.sqrt(3),1/np.sqrt(3)):
                    L.append(l); R.append(r); bc.append(tag); xn.append((points[a]+points[b])/2+z*d/2); normals.append(nv/length); weights.append(length/2)
        self.L,self.R,self.bc=np.array(L),np.array(R),np.array(bc)
        self.fx,self.normal,self.fw=np.array(xn),np.array(normals),np.array(weights)
        self.inner=self.bc==1; self.interior=self.R>=0
        self.wall=self.inner & (mode=='flow')
        self.inlet=((~self.interior)&(~self.wall)&(self.normal.real@np.array([.22,.055])<0)) if _reference is None else _reference.inlet.copy()
        self.outlet=(~self.interior)&(~self.wall)&~self.inlet
        self.in_nodes=np.zeros(nc,bool); self.out_nodes=np.zeros(nc,bool)
        self.in_nodes[self.L[self.inlet]]=True; self.out_nodes[self.L[self.outlet]]=True
        self.wall_nodes=np.zeros(nc,bool); self.wall_nodes[self.L[self.wall]]=True
        self.wall_normals=np.zeros((nc,2),dtype=self._geometry_dtype)
        np.add.at(self.wall_normals,self.L[self.wall],self.fw[self.wall,None]*self.normal[self.wall])
        self.wall_normals[self.wall_nodes]/=analytic_norm(self.wall_normals[self.wall_nodes],axis=1)[:,None]
        self.constraints=np.zeros((nc,4),bool)
        if node:
            self.constraints[self.in_nodes,:3]=True
            self.constraints[self.in_nodes&~self.out_nodes,3]=True
            self.constraints[self.wall_nodes,1:]=True
        self.src=np.zeros((nc,4),dtype=self._geometry_dtype)
        if mode=='mms': np.add.at(self.src,self.qi,self.qw[:,None]*source(self.qx,self.params,variable))
        self.heating=scatter_sum(self.qi,self.qw*np.sin(.7*self.qx[:,0]+.5*self.qx[:,1])**2,nc)
        self.target=1+.02*np.cos(self.qx[:,0])
        I=sparse.csr_matrix((np.ones(len(self.qi)),(np.arange(len(self.qi)),self.qi)),shape=(len(self.qi),nc))
        self.qrec=I+sparse.diags(delta[:,0])@self.fit[0][self.qi]+sparse.diags(delta[:,1])@self.fit[1][self.qi]
        self.qconstant=I
        self._pattern=None
        self._geometry_pattern=None

    def initial(self,p=None):
        p=self.params if p is None else p
        if self.mode=='flow':
            radius=np.linalg.norm(self.cent,axis=1); f=np.clip((radius-.55)/1.35,0,1)
            return cons(np.ones(self.nc),p[0]*np.sqrt(1.4)*np.cos(p[1])*f,p[0]*np.sqrt(1.4)*np.sin(p[1])*f,1+(p[4]-1)*(1-f)).ravel()
        if self.node: return exact(self.X).ravel()
        u=np.zeros((self.nc,4),dtype=self._geometry_dtype); np.add.at(u,self.qi,self.qw[:,None]*exact(self.qx)); return (u/self.vol[:,None]).ravel()

    def rec(self,U,coeff,ids,x,degree=2):
        d=x-self.cent[ids]; a=coeff[ids]
        b=np.column_stack((d[:,0],d[:,1],d[:,0]**2-self.mom[ids,0],d[:,0]*d[:,1]-self.mom[ids,1],d[:,1]**2-self.mom[ids,2]))
        count=5 if degree==2 else 2
        value=U[ids]+np.einsum('mi,mik->mk',b[:,:count],a[:,:count]) if degree else U[ids]
        grad=np.stack((a[:,0]+2*d[:,0,None]*a[:,2]+d[:,1,None]*a[:,3],a[:,1]+d[:,0,None]*a[:,3]+2*d[:,1,None]*a[:,4]),axis=1)
        return value,grad

    def prescribed(self,x,p,inner):
        if self.mode=='flow':
            one=np.ones(x.shape[:-1])
            return cons(one,one*p[0]*np.sqrt(1.4)*np.cos(p[1]),one*p[0]*np.sqrt(1.4)*np.sin(p[1]),one)
        r,u,v,T=prim(exact(x))
        return cons(r,u+np.sqrt(1.4)*(p[0]-self.params[0]),v+.2*(p[1]-self.params[1]),T+inner*(p[4]-1))

    def evaluate(self,state,p=None,order=None,details=False):
        p=self.params if p is None else p; order=self.order if order is None else order
        if not np.all(np.isfinite(p)) or np.any(np.real(p[2:5])<=0):
            raise ValueError('Positive viscosity, Prandtl number and boundary temperature required')
        U=np.asarray(state).reshape(-1,4); dtype=np.result_type(U,p,self.X)
        coeff=np.stack([W@U for W in self.fit],axis=1)
        lv,lg=self.rec(U,coeff,self.L,self.fx); G=primitive_gradient(lv,lg)
        UL=self.rec(U,coeff,self.L,self.fx,1)[0] if order==2 else U[self.L]
        H=np.zeros((len(self.L),4),dtype=dtype)
        traction=np.zeros((len(self.L),2),dtype=dtype); heat=np.zeros(len(self.L),dtype=dtype)
        mask=self.interior
        if np.any(mask):
            rv,rg=self.rec(U,coeff,self.R[mask],self.fx[mask]); qa=np.stack(prim(lv[mask]),axis=-1); qb=np.stack(prim(rv),axis=-1)
            d=self.cent[self.R[mask]]-self.cent[self.L[mask]]
            GG=.5*(G[mask]+primitive_gradient(rv,rg))+2*(qb[:,1:]-qa[:,1:])[:,:,None]*d[:,None,:]/np.sum(d*d,axis=1)[:,None,None]
            UR=self.rec(U,coeff,self.R[mask],self.fx[mask],1)[0] if order==2 else U[self.R[mask]]
            fv,_=viscous(prim((lv[mask]+rv)/2),GG,self.normal[mask],p,self.variable)
            H[mask]=.5*(flux(UL[mask],self.normal[mask])+flux(UR,self.normal[mask]))-1.5*(UR-UL[mask])-fv
        mask=self.inlet
        if np.any(mask):
            prescribed=self.prescribed(self.fx[mask],p,self.inner[mask]); qa=np.stack(prim(lv[mask]),axis=-1); qb=np.stack(prim(prescribed),axis=-1)
            dist=np.sqrt(self.vol[self.L[mask]]) if self.node else np.sum((self.fx[mask]-self.cent[self.L[mask]])*self.normal[mask],axis=1)
            GG=G[mask]+2*(qb[:,1:]-qa[:,1:])[:,:,None]*self.normal[mask,None,:]/dist[:,None,None]
            fv,hf=viscous(prim(prescribed),GG,self.normal[mask],p,self.variable)
            H[mask]=flux(prescribed,self.normal[mask])-fv
            traction[mask]=(qb[:,0]*qb[:,3])[:,None]*self.normal[mask]-fv[:,1:3]; heat[mask]=hf
        mask=self.wall
        if np.any(mask):
            qa=np.stack(prim(lv[mask]),axis=-1); qb=qa.astype(dtype); qb[:,1:3]=0
            if self.thermal=='isothermal': qb[:,3]=p[4]
            dist=np.sqrt(self.vol[self.L[mask]]) if self.node else np.sum((self.fx[mask]-self.cent[self.L[mask]])*self.normal[mask],axis=1)
            jump=qb[:,1:]-qa[:,1:]
            if self.thermal=='adiabatic': jump[:,2]=0
            GG=G[mask]+2*jump[:,:,None]*self.normal[mask,None,:]/dist[:,None,None]
            fv,hf=viscous(tuple(qb.T),GG,self.normal[mask],p,self.variable)
            if self.thermal=='adiabatic': fv[:,3]=0; hf=np.zeros_like(hf)
            traction[mask]=(qb[:,0]*qb[:,3])[:,None]*self.normal[mask]-fv[:,1:3]; heat[mask]=hf
            H[mask,1:3]=traction[mask]; H[mask,3]=-fv[:,3]
        mask=self.outlet
        if np.any(mask):
            if self.mode=='mms':
                q,g=exact(self.fx[mask],True); fv,hf=viscous(q,np.stack(g[1:],axis=-2),self.normal[mask],p,self.variable)
                tr=(q[0]*q[3])[:,None]*self.normal[mask]-fv[:,1:3]
            else: tr=self.normal[mask].astype(dtype); hf=np.zeros(mask.sum(),dtype=dtype)
            traction[mask]=tr; heat[mask]=hf
            uo=UL[mask]; r,u,v,T=prim(uo); un=u*self.normal[mask,0]+v*self.normal[mask,1]
            H[mask]=np.column_stack((r*un,uo[:,1]*un+tr[:,0],uo[:,2]*un+tr[:,1],uo[:,3]*un+u*tr[:,0]+v*tr[:,1]+hf))
        R=-self.src.astype(dtype); R[:,3]-=p[5]*self.heating
        np.add.at(R,self.L,self.fw[:,None]*H)
        np.add.at(R,self.R[self.interior],-self.fw[self.interior,None]*H[self.interior])
        raw=R.copy() if details else None
        if self.node:
            q=np.stack(prim(U),axis=-1); bc=np.stack(prim(self.prescribed(self.cent,p,self.inner_nodes)),axis=-1)
            inflow=self.in_nodes&~self.wall_nodes
            R[inflow,:3]=(q-bc)[inflow,:3]
            energy=inflow&~self.out_nodes; R[energy,3]=(q-bc)[energy,3]
            wall=self.wall_nodes
            R[wall,1:3]=q[wall,1:3]
            if self.thermal=='isothermal': R[wall,3]=q[wall,3]-p[4]
            elif np.any(wall):
                ids=np.flatnonzero(wall); _,grad=self.rec(U,coeff,ids,self.cent[ids]); gt=primitive_gradient(U[ids],grad)[:,2,:]
                T=q[ids,3]; mu=p[2]*1.4*T**1.5/(T+.4) if self.variable else p[2]
                R[ids,3]=-3.5*mu/p[3]*np.sum(gt*self.wall_normals[ids],axis=1)
        qrec=self.qrec if order==2 else self.qconstant; V=qrec@U; T=prim(V)[3]
        Jcell=np.zeros(self.nc,dtype=dtype)
        if self.objective=='tracking': np.add.at(Jcell,self.qi,.5*self.qw*(T-self.target)**2)
        else:
            values=heat if self.objective=='heatflux' else traction[:,0 if self.objective=='forcex' else 1]
            np.add.at(Jcell,self.L[self.inner],self.fw[self.inner]*values[self.inner])
        J=Jcell.sum()
        if details:
            return dict(R=R.ravel(),J=J,objective_local=Jcell,raw=raw.ravel(),flux=H,
                        force=np.sum(self.fw[self.inner,None]*traction[self.inner],axis=0),heat=np.sum(self.fw[self.inner]*heat[self.inner]))
        return R.ravel(),J

    def objective_gradient(self,state):
        if self.objective!='tracking':
            # Colour local objective rows, then sum their derivatives. Colouring
            # a single global scalar directly would alias simultaneous columns.
            rr,cc,colors=self.pattern(); take=rr%4==0; rr,cc=rr[take]//4,cc[take]
            gradient=np.zeros(self.nd); h=1e-30
            for color in range(colors.max()+1):
                for comp in range(4):
                    z=state.astype(complex); z[4*np.flatnonzero(colors==color)+comp]+=1j*h
                    d=self.evaluate(z,details=True)['objective_local'].imag/h
                    mask=(colors[cc//4]==color)&(cc%4==comp)
                    np.add.at(gradient,cc[mask],d[rr[mask]])
            return gradient
        U=state.reshape(-1,4); Q=self.qrec if self.order==2 else self.qconstant; V=Q@U
        r,u,v,T=prim(V); d=np.column_stack(((-V[:,3]/r+u*u+v*v)/(2.5*r),-u/(2.5*r),-v/(2.5*r),1/(2.5*r)))
        return (Q.T@(self.qw[:,None]*(T-self.target)[:,None]*d)).ravel()

    def pattern(self):
        if self._pattern is not None: return self._pattern
        st=[set([i,*s]) for i,s in enumerate(self.stencil)]; deps=[s.copy() for s in st]
        for l,r,_,_ in self.faces:
            if r>=0: deps[l].update(st[r]); deps[r].update(st[l])
        conflicts=[set() for _ in range(self.nc)]
        for dep in deps:
            for i in dep: conflicts[i].update(dep-{i})
        colors=np.full(self.nc,-1)
        for i in sorted(range(self.nc),key=lambda i:(-len(conflicts[i]),i)):
            used={colors[j] for j in conflicts[i]}; c=0
            while c in used: c+=1
            colors[i]=c
        rr=[]; cc=[]
        for i,dep in enumerate(deps):
            for k in range(4):
                rr.extend([4*i+k]*(4*len(dep))); cc.extend([4*j+l for j in sorted(dep) for l in range(4)])
        rr,cc=np.array(rr),np.array(cc); self._pattern=(rr,cc,colors)
        return self._pattern

    def jacobian(self,state,order=None,p=None):
        rr,cc,colors=self.pattern(); values=np.zeros(len(rr)); h=1e-30
        for color in range(colors.max()+1):
            for comp in range(4):
                indices=4*np.flatnonzero(colors==color)+comp; z=state.astype(complex); z[indices]+=1j*h
                d=self.evaluate(z,p=p,order=order)[0].imag/h; take=(colors[cc//4]==color)&(cc%4==comp); values[take]=d[rr[take]]
        A=sparse.csr_matrix((values,(rr,cc)),shape=(self.nd,self.nd)); A.eliminate_zeros(); return A

    def parameter_derivatives(self,state):
        R=[]; J=[]
        for k in range(6):
            p=self.params.astype(complex); p[k]+=1e-30j
            r,j=self.evaluate(state,p); R.append(r.imag/1e-30); J.append(j.imag/1e-30)
        return np.column_stack(R),np.array(J)

    def with_coordinates(self,coordinates):
        """Rebuild metric/reconstruction data, retaining reference topology and BC tags."""
        reference=self if self._reference is None else self._reference
        options={**self._options,'objective':self.objective}
        return Model(**options,coordinates=coordinates,_reference=reference)

    def _geometry_base(self,state,p):
        state=np.asarray(state);p=self.params if p is None else np.asarray(p)
        if np.iscomplexobj(self.X) or np.iscomplexobj(state) or np.iscomplexobj(p) or state.shape!=(self.nd,) or p.shape!=(6,) or not np.all(np.isfinite(state)) or not np.all(np.isfinite(p)):
            raise ValueError('Geometry differentiation needs a finite real state, parameters and base mesh')
        return state,p

    def geometry_jvp(self,state,direction,p=None):
        state,p=self._geometry_base(state,p)
        direction=np.asarray(direction)
        if np.iscomplexobj(direction):raise ValueError('Geometry direction must be real')
        direction=direction.astype(float)
        if direction.shape!=self.X.shape or not np.all(np.isfinite(direction)):
            raise ValueError('Geometry direction must be finite with shape (number of vertices,2)')
        h=1e-30; m=self.with_coordinates(self.X.astype(complex)+1j*h*direction)
        r,j=m.evaluate(state,self.params if p is None else p)
        return r.imag/h,float(j.imag/h)

    def geometry_pattern(self):
        if self._geometry_pattern is not None: return self._geometry_pattern
        # Geometry of a node control volume depends on every vertex of its
        # incident primal cells (dual polygon and its arithmetic cell centre).
        owners=[set() for _ in range(self.nc)]
        for i,cell in enumerate(self.cells):
            for owner in (cell if self.node else [i]): owners[owner].update(cell)
        st=[{i,*row} for i,row in enumerate(self.stencil)]
        deps=[row.copy() for row in st]
        for l,r,_,_ in self.faces:
            if r>=0: deps[l].update(st[r]);deps[r].update(st[l])
        deps=[set().union(*(owners[j] for j in dep)) for dep in deps]
        conflicts=[set() for _ in self.X]
        for dep in deps:
            for i in dep: conflicts[i].update(dep-{i})
        colors=np.full(len(self.X),-1)
        for i in sorted(range(len(self.X)),key=lambda i:(-len(conflicts[i]),i)):
            used={colors[j] for j in conflicts[i]};c=0
            while c in used:c+=1
            colors[i]=c
        rr=[];cc=[]
        for i,dep in enumerate(deps):
            for k in range(4):
                rr.extend([4*i+k]*(2*len(dep)));cc.extend([2*j+a for j in sorted(dep) for a in range(2)])
        self._geometry_pattern=(np.array(rr),np.array(cc),colors)
        return self._geometry_pattern

    def geometry_jacobian(self,state,progress=None,p=None):
        """Sparse R_X and global J_X on one fixed real state and boundary branch."""
        state,p=self._geometry_base(state,p)
        rr,cc,colors=self.geometry_pattern();values=np.zeros(len(rr));gradient=np.zeros(2*len(self.X));h=1e-30
        for color in range(colors.max()+1):
            for axis in range(2):
                z=self.X.astype(complex);z[colors==color,axis]+=1j*h
                m=self.with_coordinates(z);d=m.evaluate(state,self.params if p is None else p,details=True)
                take=(colors[cc//2]==color)&(cc%2==axis)
                values[take]=d['R'].imag[rr[take]]/h
                objective=take&(rr%4==0)
                np.add.at(gradient,cc[objective],d['objective_local'].imag[rr[objective]//4]/h)
                if progress is not None:progress(2*color+axis+1,2*(colors.max()+1))
        RX=sparse.csr_matrix((values,(rr,cc)),shape=(self.nd,2*len(self.X)));RX.eliminate_zeros()
        return RX,gradient

    def valid(self,state):
        if not np.all(np.isfinite(state)): return False
        q=prim(state.reshape(-1,4)); r,u,v,T=q
        return bool(np.all(r>.15)&np.all(T>.3)&np.all(u*u+v*v<.64*1.4*T))

    def diagnostics(self,state,p=None,order=None):
        p=self.params if p is None else p; order=self.order if order is None else order
        U=state.reshape(-1,4); coeff=np.stack([W@U for W in self.fit],axis=1)
        lv,_=self.rec(U,coeff,self.L,self.fx)
        UL=self.rec(U,coeff,self.L,self.fx,1)[0] if order==2 else U[self.L]
        UR=UL.copy(); interior=self.interior
        UR[interior]=self.rec(U,coeff,self.R[interior],self.fx[interior],1)[0] if order==2 else U[self.R[interior]]
        UR[self.inlet]=self.prescribed(self.fx[self.inlet],p,self.inner[self.inlet])
        if np.any(self.wall):
            rho,_,_,temp=prim(lv[self.wall]); temp=temp if self.thermal=='adiabatic' else np.full_like(temp,p[4])
            UR[self.wall]=cons(rho,np.zeros_like(rho),np.zeros_like(rho),temp)
        rv=lv.copy()
        rv[interior]=self.rec(U,coeff,self.R[interior],self.fx[interior])[0]
        minimum_rho=float('inf'); minimum_T=float('inf'); maximum_wave=0.
        for states in (UL,UR,lv,rv):
            r,u,v,T=prim(states)
            if not np.all(np.isfinite(states)) or np.any(r<=.1) or np.any(T<=.2):
                return dict(supported=False,min_rho=float(np.min(r)),min_T=float(np.min(T)))
            minimum_rho=min(minimum_rho,float(r.min())); minimum_T=min(minimum_T,float(T.min()))
            maximum_wave=max(maximum_wave,float(np.max(abs(u*self.normal[:,0]+v*self.normal[:,1])+np.sqrt(1.4*T))))
        r,u,v,T=prim(UR); un=u*self.normal[:,0]+v*self.normal[:,1]
        boundary=(~interior)&(~self.wall); margin=float(np.min(np.where(self.inlet,-un,un)[boundary]))
        return dict(supported=bool(maximum_wave<3 and margin>=-1e-10),min_rho=minimum_rho,min_T=minimum_T,max_wave=maximum_wave,min_boundary_margin=margin)

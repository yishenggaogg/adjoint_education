"""Wall-flow solves, adjoint/LU and reconverged FD; no JS runtime required."""
import contextlib,json
from pathlib import Path
import numpy as np
from scipy.sparse.linalg import spsolve
from ns2d import Model
from run import solve
from linear import Hierarchy,fgmres


def main():
    options=dict(restart=100,cycles=20,pc=dict(parts=4,overlap=1,fill=1,ordering='natural',global_its=1,local_its=1,omega=1.,shift=0.))
    results=[]
    configs=[(0,n,o,v,t) for n in (False,True) for o in (1,2) for v in (False,True) for t in ('isothermal','adiabatic')]
    configs += [(1,False,2,True,'isothermal'),(1,True,2,True,'adiabatic')]
    with open('flow_solver_iterations.log','w') as log:
        for level,node,order,variable,thermal in configs:
            m=Model(level=level,node=node,order=order,variable=variable,mode='flow',thermal=thermal)
            with contextlib.redirect_stdout(log):u,_,history,_=solve(m,options,tol=1e-12)
            A=m.jacobian(u); P=A if order==1 else m.jacobian(u,order=1)
            weights=np.repeat(m.vol,4); weights[m.constraints.ravel()]=0
            pc=Hierarchy(P.T.tocsr(),weights=weights,**options['pc']);tp=Hierarchy(P,weights=weights,**options['pc'])
            # The state residual is independent of the choice of objective.
            # Parameter 4 is exactly inactive for an adiabatic wall.
            shifted={}; h=1e-4
            for k in [1,2,4,5]:
                pa=m.params.copy();pb=pa.copy();pa[k]+=h;pb[k]-=h
                with contextlib.redirect_stdout(log):plus,_,hp,_=solve(m,options,pa,u,tol=1e-12);minus,_,hm,_=solve(m,options,pb,u,tol=1e-12)
                shifted[k]=(plus,minus,pa,pb,hp[-1],hm[-1])
            for objective in ('tracking','forcex','forcey','heatflux'):
                m.objective=objective;j=m.objective_gradient(u);rp,jp=m.parameter_derivatives(u)
                psi,adj=fgmres(A.T,-j,pc,rtol=1e-11);g=jp+psi@rp
                direct=spsolve(A.T.tocsc(),-j);lu=float(np.max(abs(psi-direct)));assert lu<1e-8,lu
                dual=[];fd=[]
                for k in range(6):
                    v,_=fgmres(A,-rp[:,k],tp,rtol=1e-11);err=float(abs(j@v+jp[k]-g[k]));assert err<1e-8,err;dual.append(err)
                    if k in shifted:
                        plus,minus,pa,pb,hp,hm=shifted[k]
                        f=float((m.evaluate(plus,pa)[1]-m.evaluate(minus,pb)[1])/(2*h));err=abs(f-g[k])
                        assert err<max(2e-7,2e-5*abs(g[k])),(level,node,order,variable,thermal,objective,k,err,g[k])
                        fd.append(dict(parameter=k,step=h,absolute_error=err,relative_error=err/max(abs(g[k]),1e-14),plus_residual=hp,minus_residual=hm))
                if thermal=='adiabatic':
                    assert g[4]==0
                    if objective=='heatflux':assert np.all(g==0) and np.all(psi==0) and adj['iterations']==0
                r=dict(level=level,node=node,order=order,variable=variable,thermal=thermal,objective=objective,dofs=m.nd,primal_residual=history[-1],adjoint_residual=adj['residual'],lu_error=lu,duality_error=max(dual),gradient=g.tolist(),fd=fd)
                results.append(r);print(json.dumps(r),flush=True)
    report=dict(passed=True,configurations=len(configs),objective_cases=len(results),results=results)
    Path('flow_solver_validation.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__=='__main__':main()

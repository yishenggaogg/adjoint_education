"""Compute a self-similar mesh family using the same run.py options."""
import json
from pathlib import Path
from run import parser,run

if __name__=='__main__':
    p=parser(); p.add_argument('--max-level',type=int,default=3); args=p.parse_args()
    if not 0<=args.max_level<=8: p.error('max-level must be 0..8')
    root=Path(args.output); results=[]
    for level in range(args.max_level+1):
        args.level=level; args.output=str(root/f'level{level}')
        results.append(run(args))
        (root/'refinement.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')

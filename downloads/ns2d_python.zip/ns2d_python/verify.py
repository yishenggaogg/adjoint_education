"""Independent regression against values exported from the browser AD kernel."""
import json
from pathlib import Path
import numpy as np
from scipy import sparse
from ns2d import Model
from linear import Hierarchy,fgmres,ilu_levels


def main():
    errors=[]; cases=[]
    for d in json.loads(Path(__file__).with_name('reference_small.json').read_text()):
        m=Model(node=d['node'],order=d['order'],variable=d['variable']); u=np.array(d['U'])
        r,j=m.evaluate(u); A=m.jacobian(u).toarray(); rp,jp=m.parameter_derivatives(u)
        e=[np.max(abs(r-d['R'])),abs(j-d['J']),np.max(abs(A-d['A'])),np.max(abs(m.objective_gradient(u)-d['j'])),np.max(abs(rp-np.array([v['R'] for v in d['Rp']]).T)),np.max(abs(jp-np.array([v['J'] for v in d['Rp']])))]
        assert max(e)<1e-10, (d['node'],d['order'],d['variable'],e)
        errors.extend(map(float,e)); cases.append(dict(node=d['node'],order=d['order'],variable=d['variable'],max_error=float(max(e))))
    # Full-fill ILU equals LU for this nonsymmetric tridiagonal system.
    A=sparse.diags([np.full(11,-.4),np.full(12,2.),np.full(11,.6)],[-1,0,1],format='csr'); truth=np.sin(np.arange(12)); rhs=A@truth
    pc,stats=ilu_levels(A,0); assert np.max(abs(pc(rhs)-truth))<1e-12
    # Exercise overlap, repeated global/local corrections and ordering, in
    # both orientations, without assuming ASM(P.T) == ASM(P).T.
    checks=[]
    for tr in (False,True):
        K=A.T.tocsr() if tr else A
        for parts,overlap,fill,ordering,g,l in [(1,0,0,'natural',1,1),(3,0,1,'rcm',2,2),(3,1,1,'natural',1,2)]:
            B=Hierarchy(K,parts=parts,overlap=overlap,fill=fill,ordering=ordering,global_its=g,local_its=l)
            x,out=fgmres(K,K@truth,B,restart=12,rtol=1e-12)
            err=float(np.max(abs(x-truth))); assert err<1e-10
            checks.append(dict(transpose=tr,error=err,residual=out['residual']))
    out=dict(passed=True,derivative_cases=cases,max_kernel_error=max(errors),linear_checks=checks)
    print(json.dumps(out,indent=2)); return out


if __name__=='__main__': main()

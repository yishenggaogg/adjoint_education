"""Right FGMRES / Richardson / restricted ASM / local ILU(k).

A serial reference for OVERU's hierarchical PC structure. No MPI, PETSc,
RANS closures, or claim of binary/runtime parity with the OVERU solver.
"""
import heapq
import time
import numpy as np
from scipy import sparse
from scipy.sparse.csgraph import reverse_cuthill_mckee
from scipy.sparse.linalg import spsolve_triangular


def ilu_levels(A,fill=1):
    A=A.tocsr(); n=A.shape[0]; levels=[]; factors=[]; shifts=0
    for i in range(n):
        orig=dict(zip(A.indices[A.indptr[i]:A.indptr[i+1]],A.data[A.indptr[i]:A.indptr[i+1]]))
        orig.setdefault(i,0.); lev={j:0 for j in orig}
        todo=[j for j in lev if j<i]; heapq.heapify(todo)
        while todo:
            j=heapq.heappop(todo)
            for k,level in levels[j].items():
                new=lev[j]+level+1
                if k>j and new<=fill and new<lev.get(k,float('inf')):
                    if k not in lev and k<i: heapq.heappush(todo,k)
                    lev[k]=new
        row={j:orig.get(j,0.) for j in sorted(lev)}
        for j in row:
            if j>=i: break
            a=row[j]/factors[j][j]; row[j]=a
            for k,b in factors[j].items():
                if k>j and k in row: row[k]-=a*b
        floor=1e-12*max(1.,max(map(abs,orig.values())))
        if not np.isfinite(row[i]): raise RuntimeError(f'ILU nonfinite pivot {i}')
        if abs(row[i])<floor: row[i]=np.copysign(floor,row[i] or 1.); shifts+=1
        levels.append(lev); factors.append(row)
    rr=[]; cc=[]; vv=[]
    for i,row in enumerate(factors):
        for j,a in row.items(): rr.append(i); cc.append(j); vv.append(a)
    LU=sparse.csr_matrix((vv,(rr,cc)),shape=A.shape)
    L=sparse.tril(LU,-1,format='csr')+sparse.eye(n,format='csr'); U=sparse.triu(LU,format='csr')
    def apply(b):
        return spsolve_triangular(U,spsolve_triangular(L,b,lower=True,unit_diagonal=True),lower=False)
    return apply,{'factor_nnz':int(LU.nnz),'shifted_pivots':shifts}


class Hierarchy:
    def __init__(self,P,parts=4,overlap=1,fill=1,ordering='natural',global_its=1,local_its=1,omega=1.,shift=0.,weights=None):
        start=time.perf_counter()
        for name,v,lo,hi in [('parts',parts,1,32),('overlap',overlap,0,3),('fill',fill,0,3),('global_its',global_its,1,5),('local_its',local_its,1,5)]:
            if not isinstance(v,int) or not lo<=v<=hi: raise ValueError(name)
        if ordering not in ('natural','rcm') or not 0<omega<=1 or not np.isfinite(shift) or shift<0: raise ValueError('Invalid PC controls')
        self.P=P.tocsr().copy(); n=P.shape[0]
        if not n or self.P.shape!=(n,n) or n%4 or not np.all(np.isfinite(self.P.data)): raise ValueError('Finite square matrix with four equations per state required')
        if weights is not None and (np.shape(weights)!=(n,) or not np.all(np.isfinite(weights)) or np.any(np.asarray(weights)<0)): raise ValueError('Invalid shift weights')
        if shift: self.P+=sparse.diags(shift*(np.ones(n) if weights is None else weights))
        self.global_its,self.local_its,self.omega=global_its,local_its,omega
        coo=self.P.tocoo(); graph=sparse.csr_matrix((np.ones(len(coo.data)),(coo.row//4,coo.col//4)),shape=(n//4,n//4))
        graph=(graph+graph.T).astype(bool).tocsr(); graph.setdiag(False); graph.eliminate_zeros()
        order=reverse_cuthill_mckee(graph,symmetric_mode=True)
        self.subdomains=[]; nnz=0; pivots=0
        for owned in np.array_split(order,min(parts,n//4)):
            ext=set(map(int,owned))
            for _ in range(overlap):
                for i in list(ext): ext.update(map(int,graph.indices[graph.indptr[i]:graph.indptr[i+1]]))
            nodes=np.array(sorted(ext))
            if ordering=='rcm': nodes=nodes[reverse_cuthill_mckee(graph[nodes][:,nodes],symmetric_mode=True)]
            ids=(4*nodes[:,None]+np.arange(4)).ravel(); keep=np.repeat(np.isin(nodes,owned),4)
            B=self.P[ids][:,ids].tocsr(); apply,stats=ilu_levels(B,fill)
            nnz+=stats['factor_nnz']; pivots+=stats['shifted_pivots']
            self.subdomains.append((ids,keep,B,apply))
        self.stats=dict(parts=len(self.subdomains),overlap=overlap,fill=fill,ordering=ordering,global_its=global_its,local_its=local_its,omega=omega,shift=shift,factor_nnz=nnz,shifted_pivots=pivots,setup_seconds=time.perf_counter()-start)

    def __call__(self,b):
        b=np.asarray(b,dtype=float)
        if b.shape!=(self.P.shape[0],) or not np.all(np.isfinite(b)): raise ValueError('Invalid PC right hand side')
        x=np.zeros_like(b)
        for _ in range(self.global_its):
            r=b-self.P@x; d=np.zeros_like(b)
            for ids,keep,B,apply in self.subdomains:
                rhs=r[ids]; local=np.zeros_like(rhs)
                for _ in range(self.local_its): local+=apply(rhs-B@local)
                d[ids[keep]]=local[keep]
            x+=self.omega*d
        if not np.all(np.isfinite(x)): raise RuntimeError('Nonfinite preconditioner result')
        return x


def fgmres(A,b,pre,restart=100,max_cycles=20,rtol=1e-10,atol=1e-13):
    if not isinstance(restart,int) or not isinstance(max_cycles,int) or restart<1 or max_cycles<1: raise ValueError('Invalid Krylov budget')
    b=np.asarray(b,dtype=float)
    if b.ndim!=1 or not len(b) or not np.all(np.isfinite(b)) or not np.isfinite(rtol) or not np.isfinite(atol) or min(rtol,atol)<0 or max(rtol,atol)==0: raise ValueError('Invalid Krylov data or tolerances')
    n=len(b); restart=min(restart,n); target=max(atol,rtol*np.linalg.norm(b))
    x=np.zeros(n); history=[]; estimates=[]; iterations=0; started=time.perf_counter()
    for cycle in range(max_cycles):
        r=b-A@x; beta=np.linalg.norm(r); history.append(float(beta))
        if beta<=target: break
        V=np.zeros((restart+1,n)); Z=np.zeros((restart,n)); H=np.zeros((restart+1,restart))
        cs=np.zeros(restart); sn=np.zeros(restart); g=np.zeros(restart+1); g[0]=beta; V[0]=r/beta
        m=0
        for j in range(restart):
            Z[j]=pre(V[j]); w=A@Z[j]
            for _ in range(2):
                for i in range(j+1):
                    h=np.dot(V[i],w); H[i,j]+=h; w-=h*V[i]
            norm=np.linalg.norm(w); H[j+1,j]=norm
            if norm>1e-16: V[j+1]=w/norm
            for i in range(j):
                a,b0=H[i,j],H[i+1,j]; H[i,j]=cs[i]*a+sn[i]*b0; H[i+1,j]=-sn[i]*a+cs[i]*b0
            rho=np.hypot(H[j,j],H[j+1,j])
            if not np.isfinite(rho) or rho==0: raise RuntimeError('FGMRES breakdown')
            cs[j]=H[j,j]/rho; sn[j]=H[j+1,j]/rho; H[j,j]=rho; H[j+1,j]=0
            g[j+1]=-sn[j]*g[j]; g[j]*=cs[j]; estimates.append(float(abs(g[j+1]))); m=j+1; iterations+=1
            if abs(g[j+1])<.2*target or norm<=1e-16: break
        y=np.linalg.solve(H[:m,:m],g[:m]); x+=y@Z[:m]
    residual=float(np.linalg.norm(A@x-b)); history.append(residual)
    report=dict(converged=bool(residual<=target),residual=residual,target=float(target),iterations=iterations,restart=restart,true_residuals=history,estimated_residuals=estimates,seconds=time.perf_counter()-started,pc=getattr(pre,'stats',{}))
    if not report['converged']: raise RuntimeError(f'FGMRES budget exhausted: {residual:.4e} > {target:.4e}')
    return x,report

"""Additional numerical checks: refinement sparsity, ILU fill, flexible GMRES."""
import json
import numpy as np
from scipy import sparse
from ns2d import Model,mesh
from linear import Hierarchy,fgmres,ilu_levels


def main():
    refined=[]; linear=[]
    for node in (False,True):
        for order in (1,2):
            for variable in (False,True):
                m=Model(level=1,node=node,order=order,variable=variable)
                u=m.initial()+1e-5*np.sin(np.arange(m.nd)); p=m.params+np.array([.001,-.002,.003,.004,.005,.006])
                A=m.jacobian(u,p=p); v=np.sin(.37*np.arange(m.nd)); w=np.cos(.51*np.arange(m.nd))
                # No colouring and no sparsity pattern used by this directional oracle.
                z=u.astype(complex)+1e-30j*v; r,j=m.evaluate(z,p)
                e=float(np.max(abs(A@v-r.imag/1e-30))); assert e<1e-10,e
                dot=float(abs(w@(A@v)-v@(A.T@w))); assert dot<1e-10,dot
                eg=float(abs(m.objective_gradient(u)@v-j.imag/1e-30)); assert eg<1e-12,eg
                rr,cc,colors=m.pattern()
                for row in np.unique(rr):
                    c=4*colors[cc[rr==row]//4]+cc[rr==row]%4
                    assert len(c)==len(set(c)), 'Colour collision'
                refined.append(dict(node=node,order=order,variable=variable,dofs=m.nd,jvp_error=e,dot_error=dot,objective_error=eg))
    rng=np.random.default_rng(428)
    n=32; dense=rng.normal(size=(n,n))*(rng.random((n,n))<.13)
    dense[np.diag_indices(n)]=np.sum(abs(dense),axis=1)+2
    A=sparse.csr_matrix(dense); truth=np.sin(np.arange(n)); rhs=A@truth
    # Dense-level fill must recover full Gaussian elimination on a graph with fill.
    full,full_stats=ilu_levels(A,n); zero,zstats=ilu_levels(A,0)
    assert full_stats['factor_nnz']>zstats['factor_nnz']
    assert np.max(abs(full(rhs)-np.linalg.solve(dense,rhs)))<1e-12
    assert np.linalg.norm(A@zero(rhs)-rhs)>1e-4
    for tr in (False,True):
        K=A.T.tocsr() if tr else A
        for ordering in ('natural','rcm'):
            for fill in range(4):
                for overlap in (0,1):
                    pc=Hierarchy(K,parts=4,overlap=overlap,fill=fill,ordering=ordering,global_its=2,local_its=2,shift=.01)
                    x,r=fgmres(K,K@truth,pc,restart=16,rtol=1e-12)
                    e=float(np.max(abs(x-truth))); assert e<1e-10
                    linear.append(dict(transpose=tr,ordering=ordering,fill=fill,overlap=overlap,error=e,residual=r['residual']))
    calls=0
    def changing(v):
        nonlocal calls
        calls+=1
        return v/(2 if calls%2 else 5)
    x,r=fgmres(A,rhs,changing,restart=32,rtol=1e-12)
    assert np.max(abs(x-truth))<1e-10
    zero,r=fgmres(A,np.zeros(n),changing); assert r['iterations']==0 and np.all(zero==0)
    try: fgmres(A,rhs,lambda x:x,restart=1,max_cycles=1,rtol=1e-14)
    except RuntimeError: pass
    else: raise AssertionError('Unconverged result accepted')
    for kwargs in ({'shift':float('nan')},{'weights':np.zeros(n-1)},{'omega':float('nan')}):
        try: Hierarchy(A,**kwargs)
        except ValueError: pass
        else: raise AssertionError('Invalid controls accepted')
    out=dict(passed=True,refined=refined,linear=linear,variable_preconditioner=True,zero_rhs=True,fail_closed=True,ilu_full_nnz=full_stats['factor_nnz'],ilu_zero_nnz=zstats['factor_nnz'])
    print(json.dumps(out,indent=2)); return out


if __name__=='__main__': main()
